#!/bin/bash

set -e

java -jar /app/*.jar
